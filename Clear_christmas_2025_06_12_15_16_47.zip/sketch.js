let player;
let seeds = [];
let trashes = [];
let trees = [];
let plantingSpots = [];
let score = 0;
let timer = 60;
let interval;

function setup() {
  createCanvas(800, 600);
  player = new Player();

  // Gerar sementes
  for (let i = 0; i < 5; i++) {
    seeds.push(new Item(random(50, width - 50), random(50, height - 50), 'seed'));
  }

  // Gerar lixo
  for (let i = 0; i < 5; i++) {
    trashes.push(new Item(random(50, width - 50), random(50, height - 50), 'trash'));
  }

  // Locais para plantar
  for (let i = 0; i < 3; i++) {
    plantingSpots.push(createVector(random(100, width - 100), random(100, height - 100)));
  }

  interval = setInterval(() => {
    if (timer > 0) timer--;
  }, 1000);
}

function draw() {
  background(200, 255, 200);
  
  fill(0);
  textSize(16);
  text(`Pontuação: ${score}`, 10, 20);
  text(`Tempo: ${timer}`, 10, 40);

  // Desenhar pontos de plantio
  for (let spot of plantingSpots) {
    fill(150, 100, 50);
    ellipse(spot.x, spot.y, 30);
  }

  // Mostrar e checar itens
  for (let seed of seeds) {
    seed.display();
  }
  for (let trash of trashes) {
    trash.display();
  }

  // Árvores plantadas
  for (let tree of trees) {
    tree.display();
  }

  player.update();
  player.display();

  if (timer <= 0) {
    gameOver();
  }
}

function keyPressed() {
  if (key === ' ') {
    // Coletar itens
    for (let i = seeds.length - 1; i >= 0; i--) {
      if (player.pos.dist(seeds[i].pos) < 30) {
        player.collect('seed');
        seeds.splice(i, 1);
        break;
      }
    }
    for (let i = trashes.length - 1; i >= 0; i--) {
      if (player.pos.dist(trashes[i].pos) < 30) {
        score += 5;
        trashes.splice(i, 1);
        break;
      }
    }

    // Plantar árvore
    if (player.hasSeed) {
      for (let i = 0; i < plantingSpots.length; i++) {
        if (player.pos.dist(plantingSpots[i]) < 30) {
          trees.push(new Tree(plantingSpots[i].x, plantingSpots[i].y));
          plantingSpots.splice(i, 1);
          player.hasSeed = false;
          score += 10;
          break;
        }
      }
    }
  }
}

function gameOver() {
  noLoop();
  clearInterval(interval);
  background(0, 150, 0);
  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text(`Tempo esgotado!\nPontuação final: ${score}`, width / 2, height / 2);
}

// Classes

class Player {
  constructor() {
    this.pos = createVector(width / 2, height / 2);
    this.speed = 3;
    this.hasSeed = false;
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) this.pos.x -= this.speed;
    if (keyIsDown(RIGHT_ARROW)) this.pos.x += this.speed;
    if (keyIsDown(UP_ARROW)) this.pos.y -= this.speed;
    if (keyIsDown(DOWN_ARROW)) this.pos.y += this.speed;
    this.pos.x = constrain(this.pos.x, 0, width);
    this.pos.y = constrain(this.pos.y, 0, height);
  }

  display() {
    fill(this.hasSeed ? 'orange' : 'red');
    ellipse(this.pos.x, this.pos.y, 30);
  }

  collect(type) {
    if (type === 'seed') {
      this.hasSeed = true;
    }
  }
}

class Item {
  constructor(x, y, type) {
    this.pos = createVector(x, y);
    this.type = type;
  }

  display() {
    if (this.type === 'seed') {
      fill('orange');
      ellipse(this.pos.x, this.pos.y, 15);
    } else if (this.type === 'trash') {
      fill('black');
      rect(this.pos.x - 5, this.pos.y - 5, 15, 15);
    }
  }
}

class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  display() {
    fill(100, 50, 0);
    rect(this.x - 5, this.y, 10, 20);
    fill(0, 200, 0);
    ellipse(this.x, this.y, 40);
  }
}
